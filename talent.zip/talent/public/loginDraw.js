
inputField("userContainer", "text", "username", "fas fa-user");
inputField("passwordContainer", "password", "password", "fas fa-lock", 30)
button("button", "Login", "login()", [], 30)



console.log("HANDMAID's TAIL")



